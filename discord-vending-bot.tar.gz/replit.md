# Discord 自動販売機 Bot

Discord上でボタンを押すと登録された商品がDMで届く自動販売機Botと、商品・在庫を管理するWebパネル。

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — APIサーバー + Discordボット起動 (port 8080)
- `pnpm --filter @workspace/admin-panel run dev` — 管理パネル起動 (port 20130)
- `pnpm run typecheck` — 全パッケージの型チェック
- `pnpm run build` — 全パッケージビルド
- `pnpm --filter @workspace/api-spec run codegen` — OpenAPI → hooks/Zodスキーマ再生成
- `pnpm --filter @workspace/db run push` — DBスキーマ変更を適用 (dev only)
- Required env: `DATABASE_URL`, `DISCORD_BOT_TOKEN`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + Discord.js 14
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod, drizzle-zod
- Frontend: React + Vite + TanStack Query + Tailwind CSS
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — APIコントラクトの唯一の真実
- `lib/db/src/schema/products.ts` — DB スキーマ (products, stock_items, purchases)
- `artifacts/api-server/src/bot.ts` — Discord Botロジック
- `artifacts/api-server/src/routes/products.ts` — 商品・在庫・購入APIルート
- `artifacts/admin-panel/src/` — 管理パネルのフロントエンド

## Architecture decisions

- BotとAPIサーバーは同一プロセス（api-server）で動く。ボットはDBに直接アクセスする。
- 在庫はstockItemsテーブルで管理。1アイテム1行、配布済みはisDelivered=trueにする。
- 管理パネルはfrontend-only（React + Vite）、APIサーバー経由でDBを操作する。
- OpenAPI specがコントラクトの唯一の真実。変更後は必ずcodegenを再実行する。

## Product

- Discordで `/shop` コマンドで商品一覧とボタンを表示
- `/shop_setup` コマンドでチャンネルに永続的なショップパネルを設置（管理者のみ）
- ユーザーがボタンを押すと在庫から1件取り出してDMで送信
- 管理パネルで商品の作成・編集・削除、在庫の追加・削除が可能

## User preferences

- 日本語UIを使用
- Discord自動販売機Bot

## Gotchas

- zod/v4 は api-server では使えない。`zod` を直接importすること。
- Bot起動はapi-serverのindex.tsでstartBot()を呼び出す。
- Discordのスラッシュコマンドはbot起動時に自動登録される。
- discord.js の TextChannel に send するには型アサーションが必要。

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
