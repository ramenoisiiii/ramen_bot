import { Router, type IRouter } from "express";
import { db, productsTable, stockItemsTable, purchasesTable } from "@workspace/db";
import { eq, and, count } from "drizzle-orm";
import { z } from "zod";

const router: IRouter = Router();

router.get("/products", async (req, res) => {
  try {
    const products = await db.select().from(productsTable).orderBy(productsTable.createdAt);
    const result = await Promise.all(
      products.map(async (p) => {
        const [stockCount] = await db
          .select({ count: count() })
          .from(stockItemsTable)
          .where(and(eq(stockItemsTable.productId, p.id), eq(stockItemsTable.isDelivered, false)));
        return { ...p, stockCount: Number(stockCount?.count ?? 0) };
      })
    );
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/products", async (req, res) => {
  try {
    const schema = z.object({
      name: z.string().min(1),
      description: z.string().default(""),
      price: z.number().int().min(0).default(0),
      isActive: z.boolean().default(true),
    });
    const data = schema.parse(req.body);
    const [product] = await db.insert(productsTable).values(data).returning();
    res.status(201).json(product);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: String(err) });
  }
});

router.put("/products/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const schema = z.object({
      name: z.string().min(1).optional(),
      description: z.string().optional(),
      price: z.number().int().min(0).optional(),
      isActive: z.boolean().optional(),
    });
    const data = schema.parse(req.body);
    const [product] = await db.update(productsTable).set(data).where(eq(productsTable.id, id)).returning();
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    res.json(product);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: String(err) });
  }
});

router.delete("/products/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(productsTable).where(eq(productsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/products/:id/stock", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const items = await db
      .select()
      .from(stockItemsTable)
      .where(eq(stockItemsTable.productId, id))
      .orderBy(stockItemsTable.createdAt);
    res.json(items);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/products/:id/stock", async (req, res) => {
  try {
    const productId = Number(req.params.id);
    const schema = z.object({
      items: z.array(z.string().min(1)),
    });
    const { items } = schema.parse(req.body);
    const inserted = await db
      .insert(stockItemsTable)
      .values(items.map((content: string) => ({ productId, content })))
      .returning();
    res.status(201).json(inserted);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: String(err) });
  }
});

router.delete("/stock/:itemId", async (req, res) => {
  try {
    const itemId = Number(req.params.itemId);
    await db.delete(stockItemsTable).where(eq(stockItemsTable.id, itemId));
    res.json({ success: true });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/purchases", async (req, res) => {
  try {
    const purchases = await db
      .select()
      .from(purchasesTable)
      .orderBy(purchasesTable.createdAt);
    res.json(purchases);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/bot/purchase", async (req, res) => {
  try {
    const schema = z.object({
      productId: z.number().int(),
      discordUserId: z.string(),
      discordUsername: z.string(),
    });
    const { productId, discordUserId, discordUsername } = schema.parse(req.body);

    const product = await db.query.productsTable.findFirst({
      where: eq(productsTable.id, productId),
    });
    if (!product || !product.isActive) {
      res.status(404).json({ error: "Product not found or inactive" });
      return;
    }

    const [stockItem] = await db
      .select()
      .from(stockItemsTable)
      .where(and(eq(stockItemsTable.productId, productId), eq(stockItemsTable.isDelivered, false)))
      .limit(1);

    if (!stockItem) {
      res.status(409).json({ error: "Out of stock" });
      return;
    }

    await db
      .update(stockItemsTable)
      .set({ isDelivered: true, deliveredAt: new Date(), deliveredTo: discordUserId })
      .where(eq(stockItemsTable.id, stockItem.id));

    await db.insert(purchasesTable).values({
      productId,
      productName: product.name,
      stockItemId: stockItem.id,
      discordUserId,
      discordUsername,
    });

    res.json({ content: stockItem.content, productName: product.name });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
