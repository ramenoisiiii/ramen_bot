import {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  Events,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  REST,
  Routes,
  SlashCommandBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { db, productsTable, stockItemsTable, purchasesTable } from "@workspace/db";
import { eq, and, count } from "drizzle-orm";
import { logger } from "./lib/logger";

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  throw new Error("DISCORD_BOT_TOKEN must be set");
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.DirectMessages],
});

async function buildShopEmbed() {
  const products = await db.select().from(productsTable).where(eq(productsTable.isActive, true));
  const productsWithStock = await Promise.all(
    products.map(async (p) => {
      const [row] = await db
        .select({ count: count() })
        .from(stockItemsTable)
        .where(and(eq(stockItemsTable.productId, p.id), eq(stockItemsTable.isDelivered, false)));
      return { ...p, stockCount: Number(row?.count ?? 0) };
    })
  );

  const embed = new EmbedBuilder()
    .setTitle("🛒 自動販売機")
    .setDescription("ボタンを押して商品を購入してください。購入した商品はDMで届きます。")
    .setColor(0x5865f2);

  for (const p of productsWithStock) {
    const stockText = p.stockCount > 0 ? `在庫: ${p.stockCount}個` : "**在庫切れ**";
    const priceText = p.price > 0 ? `${p.price}円` : "無料";
    embed.addFields({
      name: p.name,
      value: `${p.description || "説明なし"}\n💴 ${priceText} | 📦 ${stockText}`,
      inline: false,
    });
  }

  if (productsWithStock.length === 0) {
    embed.setDescription("現在販売中の商品はありません。");
  }

  return { embed, products: productsWithStock };
}

function buildShopButtons(products: Array<{ id: number; name: string; stockCount: number; isActive: boolean }>) {
  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  let currentRow = new ActionRowBuilder<ButtonBuilder>();
  let count = 0;

  for (const p of products) {
    if (count > 0 && count % 5 === 0) {
      rows.push(currentRow);
      currentRow = new ActionRowBuilder<ButtonBuilder>();
    }
    const btn = new ButtonBuilder()
      .setCustomId(`buy_${p.id}`)
      .setLabel(p.name)
      .setStyle(p.stockCount > 0 ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setDisabled(p.stockCount === 0);
    currentRow.addComponents(btn);
    count++;
    if (rows.length >= 4) break;
  }

  if (currentRow.components.length > 0) {
    rows.push(currentRow);
  }

  return rows;
}

async function handleBuyButton(interaction: ButtonInteraction): Promise<void> {
  const productId = parseInt(interaction.customId.replace("buy_", ""), 10);
  await interaction.deferReply({ ephemeral: true });

  const product = await db.query.productsTable.findFirst({
    where: eq(productsTable.id, productId),
  });

  if (!product || !product.isActive) {
    await interaction.editReply({ content: "❌ この商品は現在販売されていません。" });
    return;
  }

  const [stockItem] = await db
    .select()
    .from(stockItemsTable)
    .where(and(eq(stockItemsTable.productId, productId), eq(stockItemsTable.isDelivered, false)))
    .limit(1);

  if (!stockItem) {
    await interaction.editReply({ content: "❌ 在庫切れです。" });
    return;
  }

  await db
    .update(stockItemsTable)
    .set({
      isDelivered: true,
      deliveredAt: new Date(),
      deliveredTo: interaction.user.id,
    })
    .where(eq(stockItemsTable.id, stockItem.id));

  await db.insert(purchasesTable).values({
    productId: product.id,
    productName: product.name,
    stockItemId: stockItem.id,
    discordUserId: interaction.user.id,
    discordUsername: interaction.user.tag,
  });

  try {
    const dmEmbed = new EmbedBuilder()
      .setTitle("✅ 購入完了")
      .setDescription(`**${product.name}** をご購入いただきありがとうございます！`)
      .addFields({ name: "商品内容", value: stockItem.content })
      .setColor(0x57f287)
      .setTimestamp();

    await interaction.user.send({ embeds: [dmEmbed] });
    await interaction.editReply({ content: "✅ 購入が完了しました！DMをご確認ください。" });
  } catch {
    await interaction.editReply({
      content: "✅ 購入完了しましたが、DMを送れませんでした。DMを受け取れる設定にしてください。",
    });
  }
}

client.once(Events.ClientReady, async (c) => {
  logger.info({ tag: c.user.tag }, "Discord bot ready");

  const commands = [
    new SlashCommandBuilder()
      .setName("shop")
      .setDescription("自動販売機を開きます")
      .toJSON(),
    new SlashCommandBuilder()
      .setName("shop_setup")
      .setDescription("ショップパネルを設置します (管理者のみ)")
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .toJSON(),
  ];

  const rest = new REST().setToken(token!);
  const appId = c.application.id;
  await rest.put(Routes.applicationCommands(appId), { body: commands });
  logger.info("Slash commands registered");
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isChatInputCommand()) {
    const cmd = interaction as ChatInputCommandInteraction;
    if (cmd.commandName === "shop" || cmd.commandName === "shop_setup") {
      await cmd.deferReply({ ephemeral: cmd.commandName === "shop_setup" });
      const { embed, products } = await buildShopEmbed();
      const buttons = buildShopButtons(products);
      const payload = { embeds: [embed], components: buttons };

      if (cmd.commandName === "shop_setup") {
        const channel = cmd.channel;
        if (channel && "send" in channel) {
          await (channel as import("discord.js").TextChannel).send(payload);
        }
        await cmd.editReply({ content: "✅ ショップパネルを設置しました。" });
      } else {
        await cmd.editReply(payload);
      }
    }
  }

  if (interaction.isButton() && interaction.customId.startsWith("buy_")) {
    await handleBuyButton(interaction as ButtonInteraction);
  }
});

export function startBot() {
  client.login(token).catch((err) => {
    logger.error({ err }, "Failed to login Discord bot");
  });
}
