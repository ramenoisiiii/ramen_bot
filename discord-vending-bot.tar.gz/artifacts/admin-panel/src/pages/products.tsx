import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListProducts,
  getListProductsQueryKey,
  useCreateProduct,
  useUpdateProduct,
  useDeleteProduct,
  useListStockItems,
  getListStockItemsQueryKey,
  useAddStockItems,
  useDeleteStockItem,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Package, ChevronDown, ChevronUp, X } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const productSchema = z.object({
  name: z.string().min(1, "商品名は必須です"),
  description: z.string().default(""),
  price: z.coerce.number().int().min(0, "価格は0以上の整数です"),
  isActive: z.boolean().default(true),
});

type ProductForm = z.infer<typeof productSchema>;

function StockPanel({ productId, productName }: { productId: number; productName: string }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: items = [], isLoading } = useListStockItems(productId, {
    query: { queryKey: getListStockItemsQueryKey(productId) },
  });
  const addStock = useAddStockItems();
  const deleteStock = useDeleteStockItem();
  const [bulkText, setBulkText] = useState("");

  const handleAdd = async () => {
    const lines = bulkText.split("\n").map((l) => l.trim()).filter(Boolean);
    if (lines.length === 0) return;
    await addStock.mutateAsync(
      { id: productId, data: { items: lines } },
      {
        onSuccess: () => {
          toast({ title: `${lines.length}件の在庫を追加しました` });
          setBulkText("");
          qc.invalidateQueries({ queryKey: getListStockItemsQueryKey(productId) });
          qc.invalidateQueries({ queryKey: getListProductsQueryKey() });
        },
        onError: () => toast({ title: "在庫追加に失敗しました", variant: "destructive" }),
      }
    );
  };

  const handleDelete = async (itemId: number) => {
    await deleteStock.mutateAsync(
      { itemId },
      {
        onSuccess: () => {
          toast({ title: "在庫を削除しました" });
          qc.invalidateQueries({ queryKey: getListStockItemsQueryKey(productId) });
          qc.invalidateQueries({ queryKey: getListProductsQueryKey() });
        },
        onError: () => toast({ title: "削除に失敗しました", variant: "destructive" }),
      }
    );
  };

  return (
    <div className="mt-4 border-t pt-4 space-y-4">
      <div className="space-y-2">
        <Label>在庫を追加（1行に1アイテム）</Label>
        <Textarea
          data-testid="input-stock-bulk"
          value={bulkText}
          onChange={(e) => setBulkText(e.target.value)}
          placeholder={"シリアルコード1\nシリアルコード2\n..."}
          rows={4}
          className="font-mono text-sm"
        />
        <Button
          data-testid="button-add-stock"
          onClick={handleAdd}
          disabled={addStock.isPending || !bulkText.trim()}
          size="sm"
        >
          <Plus className="w-4 h-4 mr-1" /> 在庫追加
        </Button>
      </div>

      <div>
        <p className="text-sm font-medium mb-2">
          未配布在庫 ({items.filter((i) => !i.isDelivered).length}件)
        </p>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">読み込み中...</p>
        ) : (
          <div className="space-y-1 max-h-48 overflow-y-auto">
            {items
              .filter((i) => !i.isDelivered)
              .map((item) => (
                <div
                  key={item.id}
                  data-testid={`row-stock-${item.id}`}
                  className="flex items-center justify-between bg-muted rounded px-3 py-1.5 text-sm"
                >
                  <span className="font-mono truncate mr-2">{item.content}</span>
                  <Button
                    data-testid={`button-delete-stock-${item.id}`}
                    size="icon"
                    variant="ghost"
                    className="h-6 w-6 text-destructive shrink-0"
                    onClick={() => handleDelete(item.id)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            {items.filter((i) => !i.isDelivered).length === 0 && (
              <p className="text-sm text-muted-foreground">在庫なし</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ProductDialog({
  open,
  onClose,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  initial?: { id: number; name: string; description: string; price: number; isActive: boolean };
}) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const create = useCreateProduct();
  const update = useUpdateProduct();

  const form = useForm<ProductForm>({
    resolver: zodResolver(productSchema),
    defaultValues: initial ?? { name: "", description: "", price: 0, isActive: true },
  });

  const onSubmit = async (data: ProductForm) => {
    if (initial) {
      await update.mutateAsync(
        { id: initial.id, data },
        {
          onSuccess: () => {
            toast({ title: "商品を更新しました" });
            qc.invalidateQueries({ queryKey: getListProductsQueryKey() });
            onClose();
          },
          onError: () => toast({ title: "更新に失敗しました", variant: "destructive" }),
        }
      );
    } else {
      await create.mutateAsync(
        { data },
        {
          onSuccess: () => {
            toast({ title: "商品を作成しました" });
            qc.invalidateQueries({ queryKey: getListProductsQueryKey() });
            onClose();
          },
          onError: () => toast({ title: "作成に失敗しました", variant: "destructive" }),
        }
      );
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{initial ? "商品を編集" : "新しい商品を作成"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>商品名</FormLabel>
                  <FormControl>
                    <Input data-testid="input-product-name" placeholder="例: ゲームシリアルコード" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>説明</FormLabel>
                  <FormControl>
                    <Textarea data-testid="input-product-description" placeholder="商品の説明" {...field} rows={3} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>価格（円）</FormLabel>
                  <FormControl>
                    <Input data-testid="input-product-price" type="number" min={0} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex items-center gap-3">
                  <FormControl>
                    <Switch
                      data-testid="switch-product-active"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <FormLabel className="!mt-0">販売中</FormLabel>
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>キャンセル</Button>
              <Button
                data-testid="button-submit-product"
                type="submit"
                disabled={create.isPending || update.isPending}
              >
                {initial ? "更新" : "作成"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export default function ProductsPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: products = [], isLoading } = useListProducts();
  const deleteProduct = useDeleteProduct();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<typeof products[number] | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`「${name}」を削除しますか？`)) return;
    await deleteProduct.mutateAsync(
      { id },
      {
        onSuccess: () => {
          toast({ title: "商品を削除しました" });
          qc.invalidateQueries({ queryKey: getListProductsQueryKey() });
        },
        onError: () => toast({ title: "削除に失敗しました", variant: "destructive" }),
      }
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">商品管理</h1>
          <p className="text-muted-foreground text-sm mt-1">商品の作成・編集・在庫管理</p>
        </div>
        <Button
          data-testid="button-new-product"
          onClick={() => { setEditTarget(null); setDialogOpen(true); }}
        >
          <Plus className="w-4 h-4 mr-2" /> 新しい商品
        </Button>
      </div>

      {isLoading ? (
        <div className="grid gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="h-24" />
            </Card>
          ))}
        </div>
      ) : products.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Package className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">商品がありません。最初の商品を作成しましょう。</p>
            <Button
              className="mt-4"
              onClick={() => { setEditTarget(null); setDialogOpen(true); }}
            >
              <Plus className="w-4 h-4 mr-2" /> 商品を作成
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {products.map((p) => (
            <Card key={p.id} data-testid={`card-product-${p.id}`}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-lg">{p.name}</CardTitle>
                    <Badge variant={p.isActive ? "default" : "secondary"}>
                      {p.isActive ? "販売中" : "停止中"}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      在庫: {p.stockCount}
                    </Badge>
                    {p.price > 0 && (
                      <Badge variant="outline" className="text-xs">
                        {p.price}円
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      data-testid={`button-edit-product-${p.id}`}
                      size="icon"
                      variant="ghost"
                      onClick={() => { setEditTarget(p); setDialogOpen(true); }}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      data-testid={`button-delete-product-${p.id}`}
                      size="icon"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => handleDelete(p.id, p.name)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <Button
                      data-testid={`button-expand-product-${p.id}`}
                      size="icon"
                      variant="ghost"
                      onClick={() => setExpandedId(expandedId === p.id ? null : p.id)}
                    >
                      {expandedId === p.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
                {p.description && (
                  <p className="text-sm text-muted-foreground mt-1">{p.description}</p>
                )}
              </CardHeader>
              {expandedId === p.id && (
                <CardContent>
                  <StockPanel productId={p.id} productName={p.name} />
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}

      <ProductDialog
        open={dialogOpen}
        onClose={() => { setDialogOpen(false); setEditTarget(null); }}
        initial={editTarget ?? undefined}
      />
    </div>
  );
}
