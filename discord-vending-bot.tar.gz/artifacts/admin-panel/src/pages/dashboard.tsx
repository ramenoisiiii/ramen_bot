import { useListProducts, useListPurchases } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, ShoppingBag, AlertTriangle, CheckCircle } from "lucide-react";

export default function DashboardPage() {
  const { data: products = [], isLoading: loadingProducts } = useListProducts();
  const { data: purchases = [], isLoading: loadingPurchases } = useListPurchases();

  const activeProducts = products.filter((p) => p.isActive);
  const outOfStock = activeProducts.filter((p) => p.stockCount === 0);
  const totalStock = products.reduce((sum, p) => sum + p.stockCount, 0);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayPurchases = purchases.filter((p) => new Date(p.createdAt) >= today);

  const stats = [
    {
      label: "総商品数",
      value: loadingProducts ? "..." : products.length,
      icon: Package,
      description: `${activeProducts.length}件販売中`,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "総在庫数",
      value: loadingProducts ? "..." : totalStock,
      icon: CheckCircle,
      description: "未配布アイテム",
      color: "text-green-600",
      bg: "bg-green-50 dark:bg-green-950",
    },
    {
      label: "在庫切れ商品",
      value: loadingProducts ? "..." : outOfStock.length,
      icon: AlertTriangle,
      description: "補充が必要",
      color: "text-amber-600",
      bg: "bg-amber-50 dark:bg-amber-950",
    },
    {
      label: "今日の購入",
      value: loadingPurchases ? "..." : todayPurchases.length,
      icon: ShoppingBag,
      description: `合計 ${purchases.length}件`,
      color: "text-purple-600",
      bg: "bg-purple-50 dark:bg-purple-950",
    },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">ダッシュボード</h1>
        <p className="text-muted-foreground text-sm mt-1">Discord 自動販売機 Botの概要</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.label} data-testid={`card-stat-${s.label}`}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-3">
                <div className={`p-2 rounded-lg ${s.bg}`}>
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
              <p className="text-sm font-medium mt-1">{s.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{s.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {outOfStock.length > 0 && (
        <Card className="border-amber-200 dark:border-amber-800">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2 text-amber-700 dark:text-amber-400">
              <AlertTriangle className="w-4 h-4" />
              在庫切れの商品
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {outOfStock.map((p) => (
                <div key={p.id} className="flex items-center justify-between text-sm">
                  <span className="font-medium">{p.name}</span>
                  <span className="text-muted-foreground">在庫: 0</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">最近の購入</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingPurchases ? (
            <p className="text-sm text-muted-foreground">読み込み中...</p>
          ) : purchases.length === 0 ? (
            <p className="text-sm text-muted-foreground">まだ購入履歴はありません。</p>
          ) : (
            <div className="space-y-3">
              {[...purchases]
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .slice(0, 5)
                .map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm">
                    <div>
                      <span className="font-medium">{p.productName}</span>
                      <span className="text-muted-foreground ml-2">by {p.discordUsername}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(p.createdAt).toLocaleString("ja-JP")}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
