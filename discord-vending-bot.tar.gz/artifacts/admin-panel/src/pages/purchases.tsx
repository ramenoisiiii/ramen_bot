import { useListPurchases } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingBag } from "lucide-react";

export default function PurchasesPage() {
  const { data: purchases = [], isLoading } = useListPurchases();

  const sorted = [...purchases].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">購入履歴</h1>
        <p className="text-muted-foreground text-sm mt-1">全ての購入トランザクション</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="h-16" />
            </Card>
          ))}
        </div>
      ) : sorted.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <ShoppingBag className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">まだ購入履歴はありません。</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {sorted.map((p) => (
            <Card key={p.id} data-testid={`row-purchase-${p.id}`}>
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{p.productName}</span>
                      <Badge variant="outline" className="text-xs">ID: {p.productId}</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      購入者: <span className="font-mono">{p.discordUsername}</span>
                      <span className="ml-2 text-xs">({p.discordUserId})</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">
                      {new Date(p.createdAt).toLocaleString("ja-JP")}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
